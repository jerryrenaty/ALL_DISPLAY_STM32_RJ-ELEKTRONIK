/*
 * TouchGFX_DataTransfer.h
 *
 *  Created on: 3 janv. 2026
 *      Author: JERRYRENATY
 */

#ifndef SRC_TOUCHGFX_DATATRANSFER_H_
#define SRC_TOUCHGFX_DATATRANSFER_H_

#include <stdint.h>

/* Ces fonctions doivent garder une liaison "C" car elles sont appelées
   par le cœur de TouchGFX (Partial Framebuffer Strategy) */
extern "C" {
    void touchgfxDisplayDriverTransmitBlock(const uint8_t* pixels, uint16_t x, uint16_t y, uint16_t w, uint16_t h);
    uint32_t touchgfxDisplayDriverTransmitActive(void);
    int touchgfxDisplayDriverShouldTransferBlock(uint16_t y);
    uint8_t Touch_Internal_Read(int32_t* x, int32_t* y);
}

namespace RJ_Elektronik {
    bool HandleTouchGFX(int32_t& x, int32_t& y);
}


#endif /* SRC_TOUCHGFX_DATATRANSFER_H_ */
