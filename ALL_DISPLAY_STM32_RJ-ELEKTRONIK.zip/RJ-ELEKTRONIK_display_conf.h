/**
 ***********************************************************************************************
 * @file    RJ-ELEKTRONIK_display_conf.h
 * @author  RENATYJERRY - RJ-ELEKTRONIK
 * @brief   Configuration globale des drivers d'affichage (ILI9488 / ST7789 / GC9A01 / ST7735  )
 *          Gestion des modes de transfert SPI Bloquant et DMA pour STM32.
 * @date    12 février 2026
 ***********************************************************************************************
 * @attention
 * DÉVELOPPÉ PAR RJ-ELEKTRONIK © 2026. Tous droits réservés.
 ***********************************************************************************************
 */

#ifndef INC_RJ_ELEKTRONIK_DISPLAY_CONF_H_
#define INC_RJ_ELEKTRONIK_DISPLAY_CONF_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include <stdbool.h>
#include <stdint.h>

/* =========================================================================== */
/*                   SÉLECTION DU DRIVER ET DU MODÈLE D'ÉCRAN                  */
/* =========================================================================== */
#define Display_ILI9488      0  /* Driver pour écran 320x480                   */
#define Display_7789         0  /* Driver pour écran 240x320 / 240x280         */
#define Display_GC9A01       1  /* Driver pour écran rond 240x240              */
#define Display_ST7735       0  /* Driver pour écran 160x80                    */
/* =========================================================================== */

/* =========================================================================== */
/*                   CONFIGURATION SPÉCIFIQUE AU ST7789                        */
/* =========================================================================== */
#if Display_7789
#define st7789_240x320    0   /* 1 = Format 240x320, 0 = Format 240x280        */
#define st7789_240x280_v2 (!st7789_240x320)
#define GAMMA_OPTIMISÉE   0
#endif

/* =========================================================================== */
/*                   CONFIGURATION DU MODE DE TRANSFERT SPI                    */
/* ========================================================================+== */
#define USE_DMA_INTEGRATION       1     /* 1 = Activer DMA, 0 = SPI bloquant   */
#define USE_SPI_BLOQUANT      !USE_DMA_INTEGRATION

#if USE_DMA_INTEGRATION
#define D_CACHE_CORTEX_M7 0 /* Activer pour STM32H7 (Gestion cohérence cache)  */
#endif

/* =========================================================================== */
/*                   DIMENSIONS PHYSIQUES DE L'AFFICHAGE                       */
/* =========================================================================== */

/* --- Définition de la Largeur (WIDTH) ---                                    */
#if Display_ST7735
#define ST7789_WIDTH      160
#else
#if Display_ILI9488
#define ST7789_WIDTH      320
#else
#define ST7789_WIDTH      240
#endif
#endif
/* --- Définition de la Hauteur (HEIGHT) ---                                    */
#if Display_ST7735
#define ST7789_HEIGHT     80
#else
#if Display_7789
#if st7789_240x320
#define ST7789_HEIGHT 320
#else
#define ST7789_HEIGHT 280
#endif
#elif Display_ILI9488
#define ST7789_HEIGHT     480
#else
#define ST7789_HEIGHT     240   /* Résolution par défaut (ex: GC9A01)           */
#endif
#endif

/* =========================================================================== */
/*                   ASSIGNATION DES BROCHES DE CONTRÔLE (GPIO)               */
/* =========================================================================== */

#define CS_Pin GPIO_PIN_12
#define CS_GPIO_Port GPIOB
#define DC_Pin GPIO_PIN_13
#define DC_GPIO_Port GPIOB


#if Display_ST7735
#else
#define RST_Pin GPIO_PIN_14
#define RST_GPIO_Port GPIOB
#endif

#if Display_ILI9488
#define T_CS_Pin GPIO_PIN_12
#define T_CS_GPIO_Port GPIOB
#define T_IRQ_Pin GPIO_PIN_8
#define T_IRQ_GPIO_Port GPIOA
#endif

/* =========================================================================== */
/*                   VÉRIFICATIONS DE SÉCURITÉ RJ-ELEKTRONIK                  */
/* =========================================================================== */

/* --- 1. VÉRIFICATION DE LA SÉLECTION DES DRIVERS --- */
#define DRIVER_COUNT (Display_ILI9488 + Display_7789 + Display_GC9A01 + Display_ST7735)

#if DRIVER_COUNT == 0
    #error "ERREUR STRICTE : Aucun driver activé ! Sélectionnez un (1) driver dans la configuration."
#elif DRIVER_COUNT > 1
    #error "ERREUR STRICTE : Plusieurs drivers activés (CONFLIT). Désactivez-en un."
#endif

/* --- 2. VÉRIFICATION DES CONFLITS AVEC MATH.H --- */
#ifdef y1
    #error "CONFLIT CRITIQUE : 'y1' est déjà défini par <math.h>. Renommez vos variables en 'pos_y'."
#endif

#ifdef j1
    #error "CONFLIT CRITIQUE : 'j1' est déjà défini par <math.h>. Renommez vos variables."
#endif

/* --- 3. VÉRIFICATION DE LA COHÉRENCE DU MODE DE TRANSFERT --- */
#ifndef USE_DMA_INTEGRATION
    #warning "AVERTISSEMENT CONFIG : USE_DMA_INTEGRATION non défini. Passage en mode BLOQUANT (LENT)."
    #define USE_DMA_INTEGRATION 0
#endif

#if (USE_DMA_INTEGRATION == 1) && !defined(D_CACHE_CORTEX_M7)
    #warning "AVERTISSEMENT PERFORMANCE : DMA activé sans gestion de CACHE sur M7. Risque d'artefacts visuels."
#endif

/* --- 4. VÉRIFICATION DES PARAMÈTRES DE RÉSOLUTION --- */
#if (ST7789_WIDTH <= 0) || (ST7789_HEIGHT <= 0)
    #error "ERREUR RÉSOLUTION : Largeur ou Hauteur d'écran invalide. Vérifiez les définitions WIDTH/HEIGHT."
#endif

/* --- 5. VÉRIFICATION DES BROCHES GPIO --- */
#if !defined(CS_Pin) || !defined(DC_Pin)
    #error "ERREUR GPIO : Une ou plusieurs broches de contrôle (CS, DC) ne sont pas définies."
#endif

/* --- 6. VÉRIFICATION DE COMPATIBILITÉ TOUCHGFX --- */
#if defined(ToucheGFX) && (ToucheGFX == 1) && (USE_DMA_INTEGRATION == 0)
    #error "ERREUR TOUCHGFX : TouchGFX nécessite l'activation du mode DMA."
#endif

#ifdef __cplusplus
}
#endif

#endif /* INC_RJ_ELEKTRONIK_DISPLAY_CONF_H_ */
