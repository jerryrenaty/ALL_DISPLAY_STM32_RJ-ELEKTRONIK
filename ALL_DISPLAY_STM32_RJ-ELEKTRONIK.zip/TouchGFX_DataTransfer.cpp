#include "TouchGFX_DataTransfer.hpp"
#include "DISPLAYS_RJ-ELEKTRONIK.h"
#include "RJ-ELEKTRONIK_display_conf.h"

/* 1. Déclarations C pour les drivers */
extern "C" {
    void DisplayDriver_TransferCompleteCallback(void);
    void DrawBitmap(uint16_t x, uint16_t y, const uint16_t *bitmap, uint16_t w, uint16_t h);
    bool DMA_IsBusy(void);
    uint8_t Touch_Internal_Read(int32_t* x, int32_t* y); // Ta fonction de lecture tactile
}

volatile uint8_t isTransmittingData = 0;

/* 2. Implémentation du Namespace pour le TouchController */
namespace RJ_Elektronik {
    bool HandleTouchGFX(int32_t& x, int32_t& y) {
        // Appelle ta fonction C interne et passe les pointeurs x et y
        return (Touch_Internal_Read((int32_t*)&x, (int32_t*)&y) == 1);
    }
}

/* 3. Fonctions du Driver Display pour TouchGFX */
extern "C" {
    uint32_t touchgfxDisplayDriverTransmitActive(void) {
        return (isTransmittingData || DMA_IsBusy());
    }

    void touchgfxDisplayDriverTransmitBlock(const uint8_t* pixels, uint16_t x, uint16_t y, uint16_t w, uint16_t h) {
        isTransmittingData = 1;
        DrawBitmap(x, y, (const uint16_t*)pixels, (uint16_t)w, (uint16_t)h);
        isTransmittingData = 0;
        DisplayDriver_TransferCompleteCallback();
    }

    int touchgfxDisplayDriverShouldTransferBlock(uint16_t y) {
        return 1;
    }

#if Display_ILI9488
    // Cette fonction est utilisée par le namespace au-dessus
    uint8_t Touch_Internal_Read(int32_t* x, int32_t* y) {
        TouchPoint p = XPT2046_GetPoint();
        if (p.x != 0xFFFF) {
            *x = (int32_t)p.x;
            *y = (int32_t)p.y;
            return 1;
        }
        return 0;
    }
#endif
}
