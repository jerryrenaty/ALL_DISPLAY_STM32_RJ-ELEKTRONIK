/**
 ******************************************************************************
 * @file    ST7789_RJ-ELEKTRONIK.c
 * @author  JERRYRENATY - RJ-ELEKTRONIK
 * @brief   Implémentation du pilote d'affichage pour les contrôleurs GC9A01 / ST7789
 *          Gère la communication SPI, les primitives géométriques et les transferts DMA
 * @date    12 février 2026
 ******************************************************************************
 */

#include "DISPLAYS_RJ-ELEKTRONIK.h"
#include <string.h>
#include "font.h"
#include <stdio.h>
#include <stdlib.h>
/*
 ******************************************************************************
 *                         VARIABLES GLOBALES
 ******************************************************************************
 */

/** Handle SPI pour la communication avec l'affichage */
SPI_HandleTypeDef *hspi = NULL;

#if Display_ILI9488
/* Pointeur privé interne, uniquement pour le tactile */
#define XPT2046_ADDR_Z1 0xB0 // Mesure de pression Z1
#define XPT2046_ADDR_Z2 0xC0 // Mesure de pression Z2
static SPI_HandleTypeDef *touch_spi_handle = NULL;
#endif

/** État de rotation actuel de l'affichage */
Rotation currentRotation = ROTATION_0;

/** Dimensions dynamiques de l'affichage (mises à jour par SetRotation) */
uint16_t Display_Width = ST7789_WIDTH;
uint16_t Display_Height = ST7789_HEIGHT;

#define ST77XX_CASET  0x2A  /* Commande de définition de colonne */
#define ST77XX_RASET  0x2B  /* Commande de définition de ligne */
#define ST77XX_RAMWR  0x2C  /* Commande d'écriture en mémoire */

/** Décalages de centrage pour certaines variantes de panneaux */

uint16_t ST7789_X_Offset = 0;
uint16_t ST7789_Y_Offset = 0;

#if Display_ST7735
uint8_t _x_offset = 1;   /* Décalage X pour ST7735 */
uint8_t _y_offset = 26;  /* Décalage Y pour ST7735 */
#endif

/*
 ******************************************************************************
 *                         CONFIGURATION DMA
 ******************************************************************************
 */

#if USE_DMA_INTEGRATION
/** Tampon DMA aligné pour des performances maximales (Cache L1 / D-Bus) */
__attribute__((aligned(32)))   uint8_t dma_buffer[DMA_BUFFER_SIZE];
/** Indicateur d'occupation du bus DMA */
volatile bool dma_busy = false;
#endif

/*
 ******************************************************************************
 *                         FONCTIONS DE COMMUNICATION SPI
 ******************************************************************************
 */

/**
 * @brief  Envoie une commande (DC à l'état bas)
 * @param  cmd Octet de commande à envoyer
 */
void WriteCommand(uint8_t cmd) {
	CS_Low();
	DC_Command();
	HAL_SPI_Transmit(hspi, &cmd, 1, HAL_MAX_DELAY);
	CS_High();
}

/**
 * @brief  Envoie une donnée 8 bits (DC à l'état haut)
 * @param  data Octet de données à envoyer
 */
void WriteData(uint8_t data) {
	CS_Low();
	DC_Data();
	HAL_SPI_Transmit(hspi, &data, 1, HAL_MAX_DELAY);
	CS_High();
}

/**
 * @brief  Envoie une donnée 16 bits (coordonnées ou valeurs de couleur)
 * @param  data Donnée 16 bits à envoyer
 */
void WriteData16(uint16_t data) {
	uint8_t bytes[2] = { (uint8_t) (data >> 8), (uint8_t) (data & 0xFF) };

	CS_Low();
	DC_Data();
	HAL_SPI_Transmit(hspi, bytes, 2, HAL_MAX_DELAY);
	CS_High();
}

/*
 ******************************************************************************
 *                         GESTION DE LA FENÊTRE D'AFFICHAGE
 ******************************************************************************
 */

/**
 * @brief  Définit la zone mémoire active pour l'écriture de pixels
 * @param  x1,y1 Coordonnées de début
 * @param  x2,y2 Coordonnées de fin
 */
void SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2) {
	uint16_t actual_x1 = x1, actual_x2 = x2;
	uint16_t actual_y1 = y1, actual_y2 = y2;

#if st7789_240x280_v2
	actual_x1 += ST7789_X_Offset;
	actual_x2 += ST7789_X_Offset;
	actual_y1 += ST7789_Y_Offset;
	actual_y2 += ST7789_Y_Offset;
#elif Display_ST7735
	actual_x1 += _x_offset;
	actual_x2 += _x_offset;
	actual_y1 += _y_offset;
	actual_y2 += _y_offset;
#endif

	/* Envoi des coordonnées */
	WriteCommand(ST77XX_CASET);
	DC_Data(); /* Optimisation : On passe en mode données une fois pour toutes */
	CS_Low();
	uint8_t data[4] = { (actual_x1 >> 8), (actual_x1 & 0xFF), (actual_x2 >> 8),
			(actual_x2 & 0xFF) };
	HAL_SPI_Transmit(hspi, data, 4, HAL_MAX_DELAY);
	CS_High();

	WriteCommand(ST77XX_RASET);
	DC_Data();
	CS_Low();
	uint8_t data_y[4] = { (actual_y1 >> 8), (actual_y1 & 0xFF),
			(actual_y2 >> 8), (actual_y2 & 0xFF) };
	HAL_SPI_Transmit(hspi, data_y, 4, HAL_MAX_DELAY);
	CS_High();

	WriteCommand(ST77XX_RAMWR);
}

/*
 ******************************************************************************
 *                         INITIALISATION ET CONFIGURATION
 ******************************************************************************
 */

/**
 * @brief  Initialise l'affichage sélectionné (GC9A01 ou ST7789)
 * @param  spi_handle Pointeur vers le handle SPI configuré depuis CubeMX
 * @note   Applique les séquences de registres spécifiques au fabricant
 */
void Display_Init(SPI_HandleTypeDef *spi_handle) {
	hspi = spi_handle;

	/*
	 ******************************************************************************
	 * CONFIGURATION DU PILOTE GC9A01 (ÉCRAN ROND)
	 ******************************************************************************
	 */
#if Display_GC9A01
    /* 1. Réinitialisation matérielle */
    RST_Low();
    HAL_Delay(100);
    RST_High();
    HAL_Delay(100);

    /* 2. Séquence d'initialisation avancée */
    WriteCommand(0xEF);
    WriteCommand(0xEB);
    WriteData(0x14);
    WriteCommand(0xFE);
    WriteCommand(0xEF);
    WriteCommand(0xEB);
    WriteData(0x14);
    WriteCommand(0x84);
    WriteData(0x40);
    WriteCommand(0x85);
    WriteData(0xFF);
    WriteCommand(0x86);
    WriteData(0xFF);
    WriteCommand(0x87);
    WriteData(0xFF);
    WriteCommand(0x88);
    WriteData(0x0A);
    WriteCommand(0x89);
    WriteData(0x21);
    WriteCommand(0x8A);
    WriteData(0x00);
    WriteCommand(0x8B);
    WriteData(0x80);
    WriteCommand(0x8C);
    WriteData(0x01);
    WriteCommand(0x8D);
    WriteData(0x01);
    WriteCommand(0x8E);
    WriteData(0xFF);
    WriteCommand(0x8F);
    WriteData(0xFF);
    WriteCommand(0xB6);
    WriteData(0x00);
    WriteData(0x20);

    /* Configuration de l'affichage */
    WriteCommand(0x36);
    WriteData(0x08); /* Orientation verticale */
    WriteCommand(0x3A);
    WriteData(0x05); /* Format pixel RGB565 */

    /* Paramètres de courbe gamma et tension */
    WriteCommand(0x90);
    WriteData(0x08);
    WriteData(0x08);
    WriteData(0x08);
    WriteData(0x08);
    WriteCommand(0xBD);
    WriteData(0x06);
    WriteCommand(0xBC);
    WriteData(0x00);
    WriteCommand(0xFF);
    WriteData(0x60);
    WriteData(0x01);
    WriteData(0x04);
    WriteCommand(0xC3);
    WriteData(0x13);
    WriteCommand(0xC4);
    WriteData(0x13);
    WriteCommand(0xC9);
    WriteData(0x22);
    WriteCommand(0xBE);
    WriteData(0x11);
    WriteCommand(0xE1);
    WriteData(0x10);
    WriteData(0x0E);
    WriteCommand(0xDF);
    WriteData(0x21);
    WriteData(0x0c);
    WriteData(0x02);

    /* Paramètres gamma précis (F0 à F3) */
    WriteCommand(0xF0);
    WriteData(0x45);
    WriteData(0x09);
    WriteData(0x08);
    WriteData(0x08);
    WriteData(0x26);
    WriteData(0x2A);
    WriteCommand(0xF1);
    WriteData(0x43);
    WriteData(0x70);
    WriteData(0x72);
    WriteData(0x36);
    WriteData(0x37);
    WriteData(0x6F);
    WriteCommand(0xF2);
    WriteData(0x45);
    WriteData(0x09);
    WriteData(0x08);
    WriteData(0x08);
    WriteData(0x26);
    WriteData(0x2A);
    WriteCommand(0xF3);
    WriteData(0x43);
    WriteData(0x70);
    WriteData(0x72);
    WriteData(0x36);
    WriteData(0x37);
    WriteData(0x6F);

    /* Optimisations diverses */
    WriteCommand(0xED);
    WriteData(0x1B);
    WriteData(0x0B);
    WriteCommand(0xAE);
    WriteData(0x77);
    WriteCommand(0xCD);
    WriteData(0x63);
    WriteCommand(0x70);
    WriteData(0x07);
    WriteData(0x07);
    WriteData(0x04);
    WriteData(0x0E);
    WriteData(0x0F);
    WriteData(0x09);
    WriteData(0x07);
    WriteData(0x08);
    WriteData(0x03);
    WriteCommand(0xE8);
    WriteData(0x34);

    /* Configuration du driver source */
    WriteCommand(0x62);
    WriteData(0x18);
    WriteData(0x0D);
    WriteData(0x71);
    WriteData(0xED);
    WriteData(0x70);
    WriteData(0x70);
    WriteData(0x18);
    WriteData(0x0F);
    WriteData(0x71);
    WriteData(0xEF);
    WriteData(0x70);
    WriteData(0x70);
    WriteCommand(0x63);
    WriteData(0x18);
    WriteData(0x11);
    WriteData(0x71);
    WriteData(0xF1);
    WriteData(0x70);
    WriteData(0x70);
    WriteData(0x18);
    WriteData(0x13);
    WriteData(0x71);
    WriteData(0xF3);
    WriteData(0x70);
    WriteData(0x70);
    WriteCommand(0x64);
    WriteData(0x28);
    WriteData(0x29);
    WriteData(0xF1);
    WriteData(0x01);
    WriteData(0xF1);
    WriteData(0x00);
    WriteData(0x07);
    WriteCommand(0x66);
    WriteData(0x3C);
    WriteData(0x00);
    WriteData(0xCD);
    WriteData(0x67);
    WriteData(0x45);
    WriteData(0x45);
    WriteData(0x10);
    WriteData(0x00);
    WriteData(0x00);
    WriteData(0x00);
    WriteCommand(0x67);
    WriteData(0x00);
    WriteData(0x3C);
    WriteData(0x00);
    WriteData(0x00);
    WriteData(0x00);
    WriteData(0x01);
    WriteData(0x54);
    WriteData(0x10);
    WriteData(0x32);
    WriteData(0x98);
    WriteCommand(0x74);
    WriteData(0x10);
    WriteData(0x85);
    WriteData(0x80);
    WriteData(0x00);
    WriteData(0x00);
    WriteData(0x4E);
    WriteData(0x00);
    WriteCommand(0x98);
    WriteData(0x3e);
    WriteData(0x07);

    /* Réveil et activation de l'affichage */
    WriteCommand(0x35);
    WriteCommand(0x21); /* Inversion ON */
    WriteCommand(0x11); /* Sortie du mode sommeil */
    HAL_Delay(120);
    WriteCommand(0x29); /* Affichage ON */
    FillScreen(RED);

#if USE_DMA_INTEGRATION
    DrawString(60, 150, "DMA..", BLACK, RED, 2, &Font5x7);
#endif
    /* Écran de bienvenue */
    DrawString(60, 70, "Display", BLACK, RED, 2, &Font5x7);
    DrawString(60, 100, "GC9A01", BLACK, RED, 2, &Font5x7);
    DrawString(60, 125, "RJ-ELEKTRONIK", BLACK, RED, 2, &Font5x7);
#if USE_SPI_BLOQUANT
    DrawString(60, 150, "SPI_BLOQ..", BLACK, RED, 2, &Font5x7);
#endif

#endif

	/*
	 ******************************************************************************
	 * CONFIGURATION DU PILOTE ILI9488
	 ******************************************************************************
	 */
#if Display_ILI9488

	RST_Low();
	Delay_MS(20);

	RST_High();
	Delay_MS(120);

	WriteCommand(0x01); /* Réinitialisation logicielle */
	Delay_MS(120);

	/* Configuration du format pixel (18-bit RGB666) */
	WriteCommand(0x3A);
	WriteData(0x66); /* DPI: 18-bit, DBI: 18-bit */

	/* Configuration de l'orientation (MADCTL) */
	WriteCommand(0x36);
	WriteData(0x48); /* Ordre BGR, orientation normale */

	/* Configuration de la fréquence d'images */
	WriteCommand(0xB2); /* Contrôle de la fréquence d'images (Mode normal) */
	WriteData(0x0C); /* Ratio de division: fosc/2 */
	WriteData(0x0C); /* Horloges par ligne: 16 horloges */
	WriteData(0x00); /* Cycles d'attente: 0 */
	WriteData(0x33); /* Timing pour 60Hz */
	WriteData(0x33);

	/* Configuration gamma positive */
	WriteCommand(0xE0);
	uint8_t p_gamma[] = { 0x00, 0x03, 0x09, 0x08, 0x16, 0x0A, 0x3F, 0x78, 0x4C,
			0x09, 0x0A, 0x08, 0x16, 0x1A, 0x0F };
	for (int i = 0; i < 15; i++)
		WriteData(p_gamma[i]);

	/* Configuration gamma négative */
	WriteCommand(0xE1);
	uint8_t n_gamma[] = { 0x00, 0x16, 0x19, 0x03, 0x0F, 0x05, 0x32, 0x45, 0x46,
			0x04, 0x0E, 0x0D, 0x35, 0x37, 0x0F };
	for (int i = 0; i < 15; i++)
		WriteData(n_gamma[i]);

	/* Sortie du mode sommeil */
	WriteCommand(0x11); /* Sortie du sommeil */
	Delay_MS(120);

	/* Activation de l'affichage */
	WriteCommand(0x29); /* Affichage ON */
	Delay_MS(50);
	SetRotation(ROTATION_180);
	FillScreen(RED); /* Test visuel */

#if USE_DMA_INTEGRATION
	DrawString(60, 280, "DMA..", BLACK, RED, 2, &Font5x7);
#endif

#if USE_SPI_BLOQUANT
	DrawString(60, 280, "SPI_BLOQ..", BLACK, RED, 2, &Font5x7);
#endif
	/* Écran de bienvenue */
	DrawString(60, 200, "Display", BLACK, RED, 2, &Font5x7);
	DrawString(60, 230, "ILI9488", BLACK, RED, 2, &Font5x7);
	DrawString(60, 255, "RJ-ELEKTRONIK", BLACK, RED, 2, &Font5x7);

#else

#if Display_7789
	/* 1. Réinitialisation matérielle */
	RST_Low();
	Delay_MS(100);
	RST_High();
	Delay_MS(100);

	/* 2. Réinitialisation logicielle */
	WriteCommand(0x01);
	Delay_MS(150);
	WriteCommand(0x11);
	Delay_MS(150);

	/* 3. Configuration des paramètres de base */
	WriteCommand(0x3A);
	WriteData(0x55); /* RGB565 */
	WriteCommand(0x36);
	WriteData(0x00); /* Portrait */
	WriteCommand(0xB2);
	WriteData(0x0C);
	WriteData(0x0C);
	WriteData(0x00);
	WriteData(0x33);
	WriteData(0x33);
	WriteCommand(0xB7);
	WriteData(0x35);
	WriteCommand(0xBB);
	WriteData(0x19);
	WriteCommand(0xC0);
	WriteData(0x2C);
	WriteCommand(0xC2);
	WriteData(0x01);
	WriteCommand(0xC3);
	WriteData(0x12);
	WriteCommand(0xC4);
	WriteData(0x20);
	WriteCommand(0xC6);
	WriteData(0x0F);
	WriteCommand(0xD0);
	WriteData(0xA4);
	WriteData(0xA1);

	/* Activation de l'affichage */
	WriteCommand(0x29);
	Delay_MS(20);
	SetRotation(ROTATION_180);
#endif

	/* Initialisation de l'état DMA */
#if USE_DMA_INTEGRATION
	dma_busy = false;
#endif

#if Display_7789

#if GAMMA_OPTIMISÉE
    /* 12. CONFIGURATION GAMMA OPTIMISÉE (Couleurs vibrantes) */
    WriteCommand(0xE0);  /* PVGAMCTRL (Gamma positif) */
    WriteData(0xF0); WriteData(0x09); WriteData(0x13); WriteData(0x12);
    WriteData(0x12); WriteData(0x2B); WriteData(0x3C); WriteData(0x44);
    WriteData(0x4B); WriteData(0x1B); WriteData(0x18); WriteData(0x17);
    WriteData(0x1D); WriteData(0x21);
    Delay_MS(10);

    WriteCommand(0xE1);  /* NVGAMCTRL (Gamma négatif) */
    WriteData(0xF0); WriteData(0x09); WriteData(0x13); WriteData(0x0C);
    WriteData(0x0D); WriteData(0x27); WriteData(0x3B); WriteData(0x44);
    WriteData(0x4D); WriteData(0x0B); WriteData(0x17); WriteData(0x17);
    WriteData(0x1D); WriteData(0x21);
    Delay_MS(10);

    /* ACTIVATION DU DITHERING (Réduit les bandes sur les dégradés) */
    WriteCommand(0xB0);  /* DSIEN */
    WriteData(0x0F);
    Delay_MS(10);

    /* CONTRÔLE DE LA FRÉQUENCE D'IMAGES (Stabilité de l'image) */
    WriteCommand(0xB1); WriteData(0x01); WriteData(0x2C); WriteData(0x2D);
    Delay_MS(10);
    WriteCommand(0xB2); WriteData(0x01); WriteData(0x2C); WriteData(0x2D);
    Delay_MS(10);
    WriteCommand(0xB3); WriteData(0x01); WriteData(0x2C); WriteData(0x2D);
    WriteData(0x01); WriteData(0x2C); WriteData(0x2D);
    Delay_MS(10);
#endif

	/* 13. GESTION DE L'INVERSION D'AFFICHAGE */
#if st7789_240x280_v2
	WriteCommand(0x21); /* INVON pour version 240x280 */
	Delay_MS(10);
#endif

#if st7789_240x320
    WriteCommand(0x20);  /* INVOFF pour version 240x320 */
    Delay_MS(10);
#endif

	/* 14. ACTIVATION ET MODE NORMAL */
	WriteCommand(0x29); /* DISPON (Affichage ON) */
	Delay_MS(100);
	WriteCommand(0x13); /* NORON (Mode d'affichage normal) */
	Delay_MS(10);

	/* 15. CONFIGURATION DE LA ROTATION ET TEST VISUAL */

#if st7789_240x280_v2
	FillScreen(RED);
	DrawString(40, 70, "Display", BLACK, RED, 2, &Font5x7);
	DrawString(40, 100, "ST7789_240x280", BLACK, RED, 2, &Font5x7);
	DrawString(40, 125, "RJ-ELEKTRONIK", BLACK, RED, 2, &Font5x7);
#if USE_DMA_INTEGRATION
	DrawString(40, 150, "DMA..", BLACK, RED, 2, &Font5x7);
#endif
#if USE_SPI_BLOQUANT
    DrawString(40, 150, "SPI_BLOQ..", BLACK, RED, 2, &Font5x7);
#endif
#endif

#if st7789_240x320
    FillScreen(RED);
    DrawString(30, 90, "Display", BLACK, RED, 2, &Font5x7);
    DrawString(30, 120, "ST7789_240x320", BLACK, RED, 2, &Font5x7);
    DrawString(30, 145, "RJ-ELEKTRONIK", BLACK, RED, 2, &Font5x7);
#if USE_DMA_INTEGRATION
    DrawString(30, 170, "DMA..", BLACK, RED, 2, &Font5x7);
#endif
#if USE_SPI_BLOQUANT
    DrawString(30, 170, "SPI_BLOQ..", BLACK, RED, 2, &Font5x7);
#endif
#endif

#endif /* Display_7789 */
#endif

#if Display_ST7735

	/* 2. Sortie de veille */
	WriteCommand(0x11);
	Delay_MS(100);

	/* 3. Contrôle de la fréquence d'images (Mode Normal) */
	WriteCommand(0xB1);
	WriteData(0x01);
	WriteData(0x2C);
	WriteData(0x2D);

	/* 5. Format des pixels d'interface (TRÈS IMPORTANT) */
	WriteCommand(0x3A);
	WriteData(0x05); /* 0x05 = Couleur 16-bit (RGB565) */

	/* 6. Inversion ON (Obligatoire sur les écrans IPS WeAct) */
	WriteCommand(0x21);

	/* 7. Correction Gamma (Pour des couleurs vives) */
	WriteCommand(0xE0); /* Gamma Positif */
	uint8_t pos_gamma[] = { 0x02, 0x1c, 0x07, 0x12, 0x37, 0x32, 0x29, 0x2d,
			0x29, 0x25, 0x2b, 0x39, 0x00, 0x01, 0x03, 0x10 };
	for (int i = 0; i < 16; i++)
		WriteData(pos_gamma[i]);

	WriteCommand(0xE1); /* Gamma Négatif */
	uint8_t neg_gamma[] = { 0x03, 0x1d, 0x07, 0x06, 0x2e, 0x2c, 0x29, 0x2d,
			0x2e, 0x2e, 0x37, 0x3f, 0x00, 0x00, 0x02, 0x10 };
	for (int i = 0; i < 16; i++)
		WriteData(neg_gamma[i]);

	/* 8. Allumage final */
	WriteCommand(0x29); /* Affichage ON */
	Delay_MS(100);

	SetRotation(ROTATION_90);
	FillScreen(RED);

#if USE_SPI_BLOQUANT
	DrawString(2, 10, "SPI_BLOQ..", BLACK, RED, 2, &Font5x7);
	DrawString(2, 30, "ST7732_160x80", BLACK, RED, 2, &Font5x7);
	DrawString(2, 50, "RJ-ELEKTRONIK", BLACK, RED, 2, &Font5x7);
#endif

#if USE_DMA_INTEGRATION
	DrawString(2, 30, "ST7732_160x80", BLACK, RED, 2, &Font5x7);
	DrawString(2, 50, "RJ-ELEKTRONIK", BLACK, RED, 2, &Font5x7);
	DrawString(2, 10, "DMA..", BLACK, RED, 2, &Font5x7);
#endif

#endif

} /* Fin de Display_Init */

/**
 * @brief  Configure l'orientation de l'affichage et met à jour les dimensions
 * @param  rotation Valeur de rotation de l'énumération (0, 90, 180, 270)
 * @note   Ajuste automatiquement les décalages pour les panneaux 240x280
 */
void SetRotation(Rotation rotation) {
	currentRotation = rotation;

	/*
	 ******************************************************************************
	 * GESTION DE LA ROTATION - PILOTE ST7789
	 ******************************************************************************
	 */
#if Display_7789

	uint8_t madctl = 0;

	switch (rotation) {
	case ROTATION_0:
		madctl = 0x00;
#if st7789_240x280_v2
		Display_Width = 240;
		Display_Height = 280;
		ST7789_X_Offset = 0;
		ST7789_Y_Offset = 20;
#else
        Display_Width = 240;  Display_Height = 320;
        ST7789_X_Offset = 0;         ST7789_Y_Offset = 0;
#endif
		break;

	case ROTATION_90:
		madctl = 0x60;
#if st7789_240x280_v2
		Display_Width = 280;
		Display_Height = 240;
		ST7789_X_Offset = 20;
		ST7789_Y_Offset = 0;
#else
        Display_Width = 320;  Display_Height = 240;
        ST7789_X_Offset = 0;         ST7789_Y_Offset = 0;
#endif
		break;

	case ROTATION_180:
		madctl = 0xC0;
#if st7789_240x280_v2
		Display_Width = 240;
		Display_Height = 280;
		ST7789_X_Offset = 0;
		ST7789_Y_Offset = 20;
#else
        Display_Width = 240;  Display_Height = 320;
        ST7789_X_Offset = 0;         ST7789_Y_Offset = 0;
#endif
		break;

	case ROTATION_270:
		madctl = 0xA0;
#if st7789_240x280_v2
		Display_Width = 280;
		Display_Height = 240;
		ST7789_X_Offset = 20;
		ST7789_Y_Offset = 0;
#else
        Display_Width = 320;  Display_Height = 240;
        ST7789_X_Offset = 0;         ST7789_Y_Offset = 0;
#endif
		break;
	}

	WriteCommand(0x36); /* MADCTL */
	WriteData(madctl);
	/* Mise à jour de la fenêtre de travail plein écran */
	SetWindow(0, 0, Display_Width - 1, Display_Height - 1);
#endif

	/*
	 ******************************************************************************
	 * GESTION DE LA ROTATION - PILOTE GC9A01 (ROND)
	 ******************************************************************************
	 */
#if Display_GC9A01
    uint8_t madctl = 0;
    Display_Width = 240;
    Display_Height = 240;
    ST7789_X_Offset = 0;
    ST7789_Y_Offset = 0;

    switch (rotation) {
    case ROTATION_0:
        madctl = 0x48;
        break;
    case ROTATION_90:
        madctl = 0x28;
        break;
    case ROTATION_180:
        madctl = 0x88;
        break;
    case ROTATION_270:
        madctl = 0xE8;
        break;
    }

    WriteCommand(0x36); /* MADCTL */
    WriteData(madctl);

    /* Mise à jour de la fenêtre de travail plein écran */
    SetWindow(0, 0, Display_Width - 1, Display_Height - 1);
#endif

#if Display_ILI9488
	uint8_t madctl = 0;
	/* Mise à jour des dimensions pour la compatibilité avec font.c */
	if (rotation == ROTATION_0 || rotation == ROTATION_180) {
		Display_Width = 320;
		Display_Height = 480;
	} else {
		Display_Width = 480;
		Display_Height = 320;
	}

	switch (rotation) {
	case ROTATION_0:
		madctl = 0x48;
		break;
	case ROTATION_90:
		madctl = 0x28;
		break;
	case ROTATION_180:
		madctl = 0x88;
		break;
	case ROTATION_270:
		madctl = 0xE8;
		break;
	}

	WriteCommand(0x36);
	WriteData(madctl);
	SetWindow(0, 0, Display_Width - 1, Display_Height - 1);
#endif

#if Display_ST7735
	uint8_t madctl = 0;

	/* 1. Déterminer la valeur MADCTL selon la rotation */
	switch (rotation) {
	case ROTATION_0: /* Portrait */
		madctl = 0x48; /* BGR (bit3=1) + MY (bit7=0), MX(bit6=0), MV(bit5=0) */
		Display_Width = 80;
		Display_Height = 160;
		_x_offset = 26;  /* Pour portrait, offset X est 26 */
		_y_offset = 1;   /* Pour portrait, offset Y est 1 */
		break;

	case ROTATION_90: /* Paysage (mode normal) */
		madctl = 0x68; /* BGR + MV + MX */
		Display_Width = 160;
		Display_Height = 80;
		_x_offset = 1;    /* Pour paysage, offset X est 1 */
		_y_offset = 26;   /* Pour paysage, offset Y est 26 */
		break;

	case ROTATION_180: /* Portrait inversé */
		madctl = 0xC8; /* BGR + MX + MY */
		Display_Width = 80;
		Display_Height = 160;
		_x_offset = 26;
		_y_offset = 1;
		break;

	case ROTATION_270: /* Paysage inversé */
		madctl = 0xA8; /* BGR + MV + MY */
		Display_Width = 160;
		Display_Height = 80;
		_x_offset = 1;
		_y_offset = 26;
		break;

	default:
		madctl = 0x48;
		Display_Width = 80;
		Display_Height = 160;
		_x_offset = 26;
		_y_offset = 1;
		break;
	}

	/* 2. Envoyer la commande MADCTL avec la valeur calculée */
	WriteCommand(0x36); /* MADCTL */
	WriteData(madctl);

	/* 3. Mettre à jour la fenêtre complète */
	SetWindow(0, 0, Display_Width - 1, Display_Height - 1);
#endif
}

/*
 ******************************************************************************
 *                         FONCTIONS MODE SPI BLOQUANT
 ******************************************************************************
 */

#if USE_SPI_BLOQUANT

/**
 * @brief  Remplit tout l'écran avec une couleur
 * @param  color Valeur de couleur RGB565
 */
#if Display_ILI9488
void FillScreen(uint32_t color) {
	FillRect(0, 0, Display_Width, Display_Height, color);
}
#else
void FillScreen(uint16_t color) {
	FillRect(0, 0, Display_Width, Display_Height, color);
}
#endif

/**
 * @brief  Dessine un rectangle rempli aux coordonnées spécifiées
 * @param  x,y   Position du coin supérieur gauche
 * @param  w,h   Largeur et hauteur du rectangle
 * @param  color Valeur de couleur RGB565
 * @note   Utilise un tampon de ligne pour accélérer le transfert
 */
#if Display_ILI9488
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint32_t color) {
#else
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
#endif

#if Display_GC9A01

    /* 1. Boundary checking and clipping */
    if (x >= Display_Width || y >= Display_Height)
        return;
    if (x + w > Display_Width)
        w = Display_Width - x;
    if (y + h > Display_Height)
        h = Display_Height - y;
    if (w == 0 || h == 0)
        return;

    /* 2. Color data preparation (RGB565) */
    uint8_t hi = color >> 8;
    uint8_t lo = color & 0xFF;

    /*
     * NOTE: Dynamic stack allocation (VLA).
     * For large displays, prefer static buffer for safety.
     */
    uint8_t line_buffer[w * 2];
    for (uint16_t i = 0; i < w * 2; i += 2) {
        line_buffer[i] = hi;
        line_buffer[i + 1] = lo;
    }

    /* 3. Set drawing window */
    SetWindow(x, y, x + w - 1, y + h - 1);
    /* WriteCommand(0x2C); -- Already included in SetWindow */

    /* 4. Send data via SPI */
    CS_Low();
    DC_Data();

    for (uint16_t line = 0; line < h; line++) {
        HAL_SPI_Transmit(hspi, line_buffer, w * 2, 100);
    }

    CS_High();
#endif

#if Display_7789

    /* 1. Vérification des limites et clipping */
    if (x >= Display_Width || y >= Display_Height)
        return;
    if (x + w > Display_Width)
        w = Display_Width - x;
    if (y + h > Display_Height)
        h = Display_Height - y;
    if (w == 0 || h == 0)
        return;

    /* 2. Préparation des données de couleur (RGB565) */
    uint8_t hi = color >> 8;
    uint8_t lo = color & 0xFF;

    /*
     * NOTE: Allocation dynamique sur la pile (VLA).
     * Pour les grands écrans, préférer un tampon statique pour la sécurité.
     */
    uint8_t line_buffer[w * 2];
    for (uint16_t i = 0; i < w * 2; i += 2) {
        line_buffer[i] = hi;
        line_buffer[i + 1] = lo;
    }

    /* 3. Définir la fenêtre de dessin */
    SetWindow(x, y, x + w - 1, y + h - 1);
    /* WriteCommand(0x2C); -- Déjà inclus dans SetWindow */

    /* 4. Envoyer les données via SPI */
    CS_Low();
    DC_Data();

    for (uint16_t line = 0; line < h; line++) {
        HAL_SPI_Transmit(hspi, line_buffer, w * 2, 100);
    }

    CS_High();
#endif

#if Display_ILI9488
	/* 1. Vérification des limites et clipping */
	if (x >= Display_Width || y >= Display_Height)
		return;
	if (x + w > Display_Width)
		w = Display_Width - x;
	if (y + h > Display_Height)
		h = Display_Height - y;
	if (w == 0 || h == 0)
		return;

	SetWindow(x, y, x + w - 1, y + h - 1);

	uint8_t r = (color >> 16) & 0xFF;
	uint8_t g = (color >> 8) & 0xFF;
	uint8_t b = color & 0xFF;

	/* 1. Créer un tampon pour une ligne (max 480 pixels * 3 octets) */
	uint8_t line_buffer[480 * 3];

	/* 2. Remplir le tampon pour une ligne de largeur 'w' */
	for (uint16_t i = 0; i < w; i++) {
		line_buffer[i * 3] = r;
		line_buffer[i * 3 + 1] = g;
		line_buffer[i * 3 + 2] = b;
	}

	/* 3. Envoyer 'h' fois la ligne */
	CS_Low();
	DC_Data();
	for (uint16_t j = 0; j < h; j++) {
		/* Envoi de toute la ligne d'un coup */
		HAL_SPI_Transmit(hspi, line_buffer, w * 3, 100);
	}
	CS_High();
#endif

#if Display_ST7735

	/* 1. Vérification des limites et clipping */
	if (x >= Display_Width || y >= Display_Height)
		return;
	if (x + w > Display_Width)
		w = Display_Width - x;
	if (y + h > Display_Height)
		h = Display_Height - y;
	if (w == 0 || h == 0)
		return;

	/* 2. Préparation des données de couleur (RGB565) */
	uint8_t hi = color >> 8;
	uint8_t lo = color & 0xFF;

	/*
	 * NOTE: Allocation dynamique sur la pile (VLA).
	 * Pour les grands écrans, préférer un tampon statique pour la sécurité.
	 */
	uint8_t line_buffer[w * 2];
	for (uint16_t i = 0; i < w * 2; i += 2) {
		line_buffer[i] = hi;
		line_buffer[i + 1] = lo;
	}

	/* 3. Définir la fenêtre de dessin */
	SetWindow(x, y, x + w - 1, y + h - 1);
	/* WriteCommand(0x2C); -- Déjà inclus dans SetWindow */

	/* 4. Envoyer les données via SPI */
	CS_Low();
	DC_Data();

	for (uint16_t line = 0; line < h; line++) {
		HAL_SPI_Transmit(hspi, line_buffer, w * 2, 100);
	}

	CS_High();
#endif
}

/**
 * @brief  Affiche une image bitmap aux coordonnées spécifiées
 * @param  x,y    Position de destination
 * @param  bitmap Pointeur vers les données de l'image (uint16_t RGB565)
 * @param  w,h    Largeur et hauteur de l'image source
 */
void DrawBitmap(uint16_t x, uint16_t y, const uint16_t *bitmap, uint16_t w,
		uint16_t h) {

#if Display_7789

    /* 1. Vérification des limites et clipping */
    if (x >= Display_Width || y >= Display_Height)
        return;

    uint16_t draw_width = w;
    uint16_t draw_height = h;

    if (x + w > Display_Width)
        draw_width = Display_Width - x;
    if (y + h > Display_Height)
        draw_height = Display_Height - y;

    if (draw_width == 0 || draw_height == 0)
        return;

    /* Tampon temporaire pour la conversion d'endianness des lignes */
    uint8_t line_buffer[draw_width * 2];

    /* 2. Définir la fenêtre de dessin */
    SetWindow(x, y, x + draw_width - 1, y + draw_height - 1);
    /* WriteCommand(0x2C); -- Déjà géré dans SetWindow */

    CS_Low();
    DC_Data();

    /* 3. Traiter et envoyer l'image ligne par ligne */
    for (uint16_t row = 0; row < draw_height; row++) {
        const uint16_t *src = &bitmap[row * w];

        /* Convertir les pixels 16 bits en tampon 8 bits (Big Endian) */
        for (uint16_t col = 0; col < draw_width; col++) {
            uint16_t pixel = src[col];
            line_buffer[col * 2] = (uint8_t)(pixel >> 8);
            line_buffer[col * 2 + 1] = (uint8_t)(pixel & 0xFF);
        }

        /* Transmettre la ligne complète */
        HAL_SPI_Transmit(hspi, line_buffer, draw_width * 2, 1000);
    }

    CS_High();
#endif

#if Display_ILI9488
	/* 1. Vérification des limites et clipping */
	if (x >= Display_Width || y >= Display_Height || bitmap == NULL)
		return;

	uint16_t draw_width = (x + w > Display_Width) ? (Display_Width - x) : w;
	uint16_t draw_height = (y + h > Display_Height) ? (Display_Height - y) : h;

	/* 2. Définir la fenêtre de dessin */
	SetWindow(x, y, x + draw_width - 1, y + draw_height - 1);

	/* 3. Traiter le tableau de pixels */
	for (uint32_t i = 0; i < (uint32_t) draw_width * draw_height; i++) {
		uint16_t pixel565 = bitmap[i];

		/* Conversion RGB565 (16bit) vers RGB888 (24bit) */
		/* Extraction des composantes de couleur */
		uint8_t r = (pixel565 & 0xF800) >> 8; /* Garder les 5 bits supérieurs et décaler */
		uint8_t g = (pixel565 & 0x07E0) >> 3; /* Garder les 6 bits du milieu */
		uint8_t b = (pixel565 & 0x001F) << 3; /* Garder les 5 bits inférieurs */

		/* 4. Envoyer 3 octets */
		WriteData(r);
		WriteData(g);
		WriteData(b);
	}
#endif

}
#endif /* USE_SPI_BLOQUANT */

/*
 ******************************************************************************
 *                         FONCTIONS MODE DMA (ASYNCHRONE)
 ******************************************************************************
 */

#if USE_DMA_INTEGRATION

/**
 * @brief  Remplit tout l'écran en utilisant DMA (non-bloquant)
 * @param  color Valeur de couleur RGB565
 */
#if Display_ILI9488
void FillScreen(uint32_t color) {
	FillRect(0, 0, Display_Width, Display_Height, color);
}
#else
void FillScreen(uint16_t color) {
	FillRect(0, 0, Display_Width, Display_Height, color);
}
#endif

/*
 ******************************************************************************
 *                         FONCTIONS DE DESSIN DMA
 ******************************************************************************
 */

/**
 * @brief  Remplit un rectangle en utilisant DMA ligne par ligne
 * @note   Divise automatiquement le rectangle si la largeur dépasse la taille du tampon
 */
#if Display_ILI9488
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint32_t color)
#else
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color)
#endif
{
#if Display_ILI9488
	/* 1. Vérification des limites et clipping */
	if (x >= Display_Width || y >= Display_Height)
		return;
	if (x + w > Display_Width)
		w = Display_Width - x;
	if (y + h > Display_Height)
		h = Display_Height - y;

	/* 2. Préparer le tampon (une seule ligne) */
	uint8_t r = (color >> 16) & 0xFF;
	uint8_t g = (color >> 8) & 0xFF;
	uint8_t b = color & 0xFF;

	uint32_t bytes_per_line = w * 3;

	for (uint32_t i = 0; i < w; i++) {
		dma_buffer[i * 3] = r;
		dma_buffer[i * 3 + 1] = g;
		dma_buffer[i * 3 + 2] = b;
	}

#if D_CACHE_CORTEX_M7
    /* 3. Nettoyer le cache D (critique pour STM32H7) */
    SCB_CleanDCache_by_Addr((uint32_t*) dma_buffer, bytes_per_line);
#endif

	/* 4. Définir la fenêtre */
	SetWindow(x, y, x + w - 1, y + h - 1);

	/* 5. Boucle de transfert DMA - CS maintenu bas pour tout le rectangle */
	CS_Low(); /* CS bas UNE FOIS pour tout le rectangle */
	DC_Data(); /* Mode données */

	dma_busy = false; /* Initialisation propre */

	for (uint16_t line = 0; line < h; line++) {
		WaitDMA(); /* Attendre la fin du DMA précédent */

		dma_busy = true;

		/* Démarrer la transmission DMA pour cette ligne */
		if (HAL_SPI_Transmit_DMA(hspi, dma_buffer, bytes_per_line) != HAL_OK) {
			/* Gestion d'erreur */
			dma_busy = false;
			break;
		}

		/* Note: CS reste bas, DC reste en mode données */
		/* Le CPU peut effectuer d'autres tâches pendant que le DMA travaille */
	}

	/* 6. Attendre la dernière ligne et terminer */
	WaitDMA();
	CS_High(); /* CS haut seulement à la fin */

#else
	/* 1. Vérification des limites et clipping */
	if (x >= Display_Width || y >= Display_Height)
		return;
	if (x + w > Display_Width)
		w = Display_Width - x;
	if (y + h > Display_Height)
		h = Display_Height - y;

	uint16_t bytes_per_line = w * 2;

	/* Utiliser le tampon DMA (moitiés A et B) pour éviter l'allocation sur la pile */
	uint8_t *p_buffer[2] = { dma_buffer, &dma_buffer[DMA_BUFFER_SIZE / 2] };

	/* Préparer deux lignes de couleur (avec échange d'endianness) */
	uint16_t color_swapped = __REV16(color);
	for (uint16_t i = 0; i < w; i++) {
		((uint16_t*) p_buffer[0])[i] = color_swapped;
		((uint16_t*) p_buffer[1])[i] = color_swapped;
	}

#if D_CACHE_CORTEX_M7
    SCB_CleanDCache_by_Addr((uint32_t*)dma_buffer, DMA_BUFFER_SIZE);
#endif

	SetWindow(x, y, x + w - 1, y + h - 1);
	CS_Low();
	DC_Data();

	for (uint16_t line = 0; line < h; line++) {
		WaitDMA(); /* Attendre la fin de la ligne précédente */
		dma_busy = true;
		/* Alterner les tampons pour une disponibilité maximale */
		HAL_SPI_Transmit_DMA(hspi, p_buffer[line % 2], bytes_per_line);
	}

	WaitDMA();
	CS_High();
#endif
}

/**
 * @brief  Affiche un bitmap en utilisant DMA avec conversion d'endianness
 */
void DrawBitmap(uint16_t x, uint16_t y, const uint16_t *bitmap, uint16_t w,
		uint16_t h) {

#if Display_ILI9488

	/* 1. Vérification des paramètres */
	if (bitmap == NULL)
		return;

	/* Clipping de sécurité */
	uint16_t draw_w = (x + w > ST7789_WIDTH) ? (ST7789_WIDTH - x) : w;
	uint16_t draw_h = (y + h > ST7789_HEIGHT) ? (ST7789_HEIGHT - y) : h;

	SetWindow(x, y, x + draw_w - 1, y + draw_h - 1);

	CS_Low();
	DC_Data();

	uint32_t bytes_per_line = draw_w * 3;
	/* Utiliser le double tampon pour ne pas bloquer le CPU pendant l'envoi DMA */
	uint8_t *p_buffer[2] = { dma_buffer, &dma_buffer[DMA_BUFFER_SIZE / 2] };

	for (uint16_t line = 0; line < draw_h; line++) {
		uint8_t side = line % 2;
		uint8_t *dst = p_buffer[side];
		const uint16_t *src = &bitmap[line * w];

		/* --- CONVERSION CRUCIALE : RGB565 (TouchGFX) -> RGB888 (Écran) --- */
		for (uint16_t i = 0; i < draw_w; i++) {
			uint16_t p = src[i];
			*dst++ = (p & 0xF800) >> 8; /* R */
			*dst++ = (p & 0x07E0) >> 3; /* G */
			*dst++ = (p & 0x001F) << 3; /* B */
		}

#if D_CACHE_CORTEX_M7
	    SCB_CleanDCache_by_Addr((uint32_t*) p_buffer[side], bytes_per_line);
#endif

		WaitDMA(); /* Attendre que la ligne précédente soit partie */
		dma_busy = true;
		HAL_SPI_Transmit_DMA(hspi, p_buffer[side], bytes_per_line);
	}

	WaitDMA();
	CS_High();

#else

    if (x >= Display_Width || y >= Display_Height || bitmap == NULL)
        return;

    uint16_t draw_width = (x + w > Display_Width) ? (Display_Width - x) : w;
    uint16_t draw_height = (y + h > Display_Height) ? (Display_Height - y) : h;

    SetWindow(x, y, x + draw_width - 1, y + draw_height - 1);

    CS_Low();
    DC_Data();

    uint16_t bytes_per_line = draw_width * 2;
    uint8_t *p_buffer[2] = { dma_buffer,                     /* Buffer A (start) */
            &dma_buffer[DMA_BUFFER_SIZE / 2]  /* Buffer B (middle) */
            };

    for (uint16_t line = 0; line < draw_height; line++) {
        uint8_t current_side = line % 2; /* Toggle between 0 (A) and 1 (B) */
        const uint16_t *src = &bitmap[line * w];
        uint16_t *dst = (uint16_t*) p_buffer[current_side];

        /* --- STEP 1: Prepare line (CPU) --- */
        /* Use __REV16 for byte swapping (very fast on STM32) */
        for (uint16_t i = 0; i < draw_width; i++) {
            dst[i] = __REV16(src[i]);
        }

#if D_CACHE_CORTEX_M7
        SCB_CleanDCache_by_Addr((uint32_t*)dst, bytes_per_line);
#endif

        /* --- STEP 2: Transmit (DMA) --- */
        /* Wait for PREVIOUS transfer to complete before starting this one */
        WaitDMA();

        dma_busy = true;
        HAL_SPI_Transmit_DMA(hspi, (uint8_t*) dst, bytes_per_line);

        /* CPU immediately starts preparing next line in the other buffer */
    }

    WaitDMA(); /* Wait for last line to complete */
    CS_High();
#endif
}
#if Display_ILI9488
void DrawBitmapFullZoom(const uint16_t *bitmap) {
	/* 1. Définition de la fenêtre sur tout l'écran ILI9488 (480x320) */
	SetWindow(0, 0, 479, 319);

	CS_Low();
	DC_Data();

	/* 2. Déclaration des tampons (On sépare ton dma_buffer en deux) */
	// Assure-toi que DMA_BUFFER_SIZE est au moins à 4096 dans tes defines
	uint8_t *p_buffer[2] = { dma_buffer, &dma_buffer[DMA_BUFFER_SIZE / 2] };

	/* 3. Boucle d'affichage avec Zoom x1.5 */
	for (uint16_t y_dest = 0; y_dest < 320; y_dest++) {
		uint8_t side = y_dest % 2;
		uint8_t *dst = p_buffer[side];

		// On calcule la ligne source (y_dest / 1.33) pour transformer 240 en 320
		uint16_t y_src = (y_dest * 240) / 320;
		const uint16_t *src_line = &bitmap[y_src * 320]; // 320 est la largeur source (IMG_W)

		// On pré-calcule le saut pour éviter la division dans la boucle
		uint32_t x_ratio = (320 << 16) / 480;

		for (uint16_t x_dest = 0; x_dest < 480; x_dest++) {
			// 1. Calcul rapide de l'index source
			uint16_t x_src = (x_dest * x_ratio) >> 16;
			uint16_t p = src_line[x_src];

			// 2. TA MÉTHODE qui fonctionne (Inversion d'octets camera)
			uint8_t b1 = p & 0xFF;
			uint8_t b2 = p >> 8;
			uint16_t p_real = (b1 << 8) | b2;

			// 3. Conversion RGB565 -> RGB888 précise
			*dst++ = (p_real >> 8) & 0xF8;         // Rouge (5 bits -> 8 bits)
			*dst++ = (p_real >> 3) & 0xFC;         // Vert  (6 bits -> 8 bits)
			*dst++ = (p_real << 3) & 0xF8;         // Bleu  (5 bits -> 8 bits)
		}

		/* 4. Gestion du Cache et envoi DMA */
		// Une ligne fait 480 * 3 = 1440 octets
#if D_CACHE_CORTEX_M7
        SCB_CleanDCache_by_Addr((uint32_t*)p_buffer[side], 1440);
#endif

		WaitDMA(); // On attend que le DMA ait fini la ligne d'avant
		dma_busy = true;
		HAL_SPI_Transmit_DMA(hspi, p_buffer[side], 1440);
	}

	WaitDMA(); // Attendre la toute dernière ligne
	CS_High();
}

#endif

/*
 ******************************************************************************
 *                         SERVICES SYSTÈME ET CALLBACKS
 ******************************************************************************
 */

/**
 * @brief  Vérifie si le DMA est occupé
 * @return true si le DMA est occupé, false sinon
 */
bool DMA_IsBusy(void) {
	return dma_busy;
}

/**
 * @brief  Attend la fin du transfert DMA
 */
void WaitDMA(void) {
	while (dma_busy) {
		__NOP();
	}
}

/**
 * @brief  Callback de fin de transfert DMA
 */
void DMA_Complete(void) {
	dma_busy = false;
}

/**
 * @brief  Callback de fin de transmission SPI (Appelé par HAL)
 */
void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi_ptr) {
	if (hspi_ptr->Instance == hspi->Instance) {
		DMA_Complete();
	}
}

/*
 ******************************************************************************
 *                DÉVELOPPÉ PAR RJ-ELEKTRONIK © 2026
 ******************************************************************************
 */
#endif /* USE_DMA_INTEGRATION */

#if Display_ILI9488

/* Matrice de calibration par défaut (Coordonnées approximatives pour ILI9488) */
 TouchCalib myCalib = { 0.0005f, -0.0843f, 331.00f, 0.1277f, 0.0007f, -25.73f, 0 };

/**
 * @brief  Lecture brute des valeurs du XPT2046
 * @param  cmd Commande de lecture (axe X ou Y)
 * @return Valeur brute 12 bits
 */
static uint16_t XPT2046_Read_Raw(uint8_t cmd) {
#if USE_DMA_INTEGRATION
	WaitDMA();
#endif

	uint8_t tx[3] = { cmd, 0x00, 0x00 };
	uint8_t rx[3] = { 0 };

	T_CS_Low();

	if (HAL_SPI_TransmitReceive(touch_spi_handle, tx, rx, 3, 10) != HAL_OK) {
		T_CS_High();
		return 0;
	}

	T_CS_High();

	uint16_t res = ((uint16_t) rx[1] << 8) | rx[2];
	res >>= 3;

	return res & 0x0FFF;
}

/**
 * @brief  Lecture filtrée du tactile (moyenne des 8 valeurs centrales)
 * @param  axis_addr Adresse de l'axe (X ou Y)
 * @return Valeur filtrée
 */
static uint16_t XPT2046_Read_Filtered(uint8_t axis_addr) {
	uint16_t values[16];
	uint32_t sum = 0;

	/* Lecture de 16 échantillons */
	for (int i = 0; i < 16; i++) {
		values[i] = XPT2046_Read_Raw(axis_addr);
	}

	/* Tri par sélection COMPLET (plus sûr pour éliminer le bruit haut et bas) */
	for (int i = 0; i < 15; i++) {
		int min = i;
		for (int j = i + 1; j < 16; j++) {
			if (values[j] < values[min])
				min = j;
		}
		uint16_t temp = values[i];
		values[i] = values[min];
		values[min] = temp;
	}

	/* Moyenne des 8 valeurs centrales (Index 4 à 11) */
	/* Cela élimine les 4 "pics" de bruit en bas et les 4 "pics" en haut */
	for (int i = 4; i < 12; i++) {
		sum += values[i];
	}

	return (uint16_t) (sum >> 3); /* ">> 3" est identique à "/ 8" mais plus rapide */
}

/**
 * @brief  Vérifie si le doigt est posé sur l'écran (Logique inversée)
 * @return 1 si pressé, 0 sinon
 */
uint8_t XPT2046_IsPressed(void) {
	return (HAL_GPIO_ReadPin(T_IRQ_GPIO_Port, T_IRQ_Pin) == GPIO_PIN_RESET);
}

/**
 * @brief  Mesure la "force" de l'appui
 * @return Valeur de pression relative (plus c'est haut, plus on appuie fort)
 */
uint16_t XPT2046_GetPressure(void) {
	uint16_t z1 = XPT2046_Read_Filtered(XPT2046_ADDR_Z1);
	uint16_t z2 = XPT2046_Read_Filtered(XPT2046_ADDR_Z2);

	if (z1 == 0)
		return 0;

	// Formule simplifiée pour obtenir une valeur de pression exploitable
	// Plus l'appui est ferme, plus l'écart entre Z2 et Z1 est grand par rapport à X
	// Ici on retourne un score simple :
	return (z2 - z1);
}


/**
 * @brief  Calcule la position réelle en pixels en appliquant la matrice de calibration
 * @return Point tactile converti en pixels écran
 */
/**
 * @brief  Récupère un point valide. Retourne 1 si le point est bon, 0 sinon.
 */
uint8_t XPT2046_GetPointSafe(TouchPoint *p_out) {
    // 1. Vérification physique immédiate
    if (!XPT2046_IsPressed()) return 0;

    // 2. Vérifier la pression (seuil)
    if (XPT2046_GetPressure() < 100) return 0;

    // 3. Lecture filtrée
    uint16_t rx = XPT2046_Read_Filtered(XPT2046_ADDR_X);
    uint16_t ry = XPT2046_Read_Filtered(XPT2046_ADDR_Y);

    // 4. Éliminer le bruit extrême du contrôleur
    if (rx < 50 || rx > 4050 || ry < 50 || ry > 4050) return 0;

    // 5. Calcul de la transformation affine
    float fx = myCalib.a * rx + myCalib.b * ry + myCalib.c;
    float fy = myCalib.d * rx + myCalib.e * ry + myCalib.f;

    // 6. Conversion et Contrainte (Clamp) aux dimensions de l'écran
    int16_t tx = (int16_t)fx;
    int16_t ty = (int16_t)fy;

    if (tx < 0) tx = 0;
    if (tx >= Display_Width) tx = Display_Width - 1;
    if (ty < 0) ty = 0;
    if (ty >= Display_Height) ty = Display_Height - 1;

    // 7. On remplit la structure seulement si tout est OK
    p_out->x = (uint16_t)tx;
    p_out->y = (uint16_t)ty;

    return 1; // Succès !
}

/**
 * @brief  Lance la procédure de calibration interactive sur l'écran
 */
void XPT2046_Calibrate() {
	/* 1. Appliquer la rotation (cela met à jour Display_Width/Height) */
	SetRotation(currentRotation);

	/* 2. Utiliser les variables dynamiques du driver */
	uint16_t current_w = Display_Width;
	uint16_t current_h = Display_Height;

	uint16_t margin = 40;

	/* 3. Cibles de calibration (Positions LCD réelles selon la rotation actuelle) */
	uint16_t tx[3] = { (uint16_t) margin, (uint16_t) (current_w - margin),
			(uint16_t) (current_w / 2) };
	uint16_t ty[3] = { (uint16_t) margin, (uint16_t) (current_h / 2),
			(uint16_t) (current_h - margin) };

	uint16_t rx[3], ry[3];

	/* Points de calibration */
	for (int i = 0; i < 3; i++) {
		/* Dessiner la cible (Croix blanche) */
		FillRect(tx[i] - 10, ty[i], 21, 1, 0xFFFF);
		FillRect(tx[i], ty[i] - 10, 1, 21, 0xFFFF);

		/* Attendre que l'utilisateur appuie */
		while (!XPT2046_IsPressed())
			;

		/* Petite pause pour stabiliser la pression avant la lecture */
		Delay_MS(50);

		/* Lecture filtrée (moyenne des 8 valeurs centrales) */
		rx[i] = XPT2046_Read_Filtered(XPT2046_ADDR_X);
		ry[i] = XPT2046_Read_Filtered(XPT2046_ADDR_Y);

		/* Attendre que l'utilisateur relâche */
		while (XPT2046_IsPressed())
			;

		/* Effacer la cible pour indiquer que le point est enregistré */
		FillRect(tx[i] - 10, ty[i], 21, 1, 0x0000);
		FillRect(tx[i], ty[i] - 10, 1, 21, 0x0000);

		Delay_MS(300); /* Anti-rebond entre les points */
	}

	/* 4. Calcul de la Matrice Affine */
	float f_rx[3] = { (float) rx[0], (float) rx[1], (float) rx[2] };
	float f_ry[3] = { (float) ry[0], (float) ry[1], (float) ry[2] };
	float f_tx[3] = { (float) tx[0], (float) tx[1], (float) tx[2] };
	float f_ty[3] = { (float) ty[0], (float) ty[1], (float) ty[2] };

	float det = f_rx[0] * (f_ry[1] - f_ry[2]) + f_rx[1] * (f_ry[2] - f_ry[0])
			+ f_rx[2] * (f_ry[0] - f_ry[1]);

	if (det != 0.0f) {
		myCalib.a = (f_tx[0] * (f_ry[1] - f_ry[2])
				+ f_tx[1] * (f_ry[2] - f_ry[0]) + f_tx[2] * (f_ry[0] - f_ry[1]))
				/ det;
		myCalib.b = (f_tx[0] * (f_rx[2] - f_rx[1])
				+ f_tx[1] * (f_rx[0] - f_rx[2]) + f_tx[2] * (f_rx[1] - f_rx[0]))
				/ det;
		myCalib.c = (f_tx[0] * (f_rx[1] * f_ry[2] - f_rx[2] * f_ry[1])
				+ f_tx[1] * (f_rx[2] * f_ry[0] - f_rx[0] * f_ry[2])
				+ f_tx[2] * (f_rx[0] * f_ry[1] - f_rx[1] * f_ry[0])) / det;

		myCalib.d = (f_ty[0] * (f_ry[1] - f_ry[2])
				+ f_ty[1] * (f_ry[2] - f_ry[0]) + f_ty[2] * (f_ry[0] - f_ry[1]))
				/ det;
		myCalib.e = (f_ty[0] * (f_rx[2] - f_rx[1])
				+ f_ty[1] * (f_rx[0] - f_rx[2]) + f_ty[2] * (f_rx[1] - f_rx[0]))
				/ det;
		myCalib.f = (f_ty[0] * (f_rx[1] * f_ry[2] - f_rx[2] * f_ry[1])
				+ f_ty[1] * (f_rx[2] * f_ry[0] - f_rx[0] * f_ry[2])
				+ f_ty[2] * (f_rx[0] * f_ry[1] - f_rx[1] * f_ry[0])) / det;

		myCalib.isCalibrated = 1; /* Marqueur de succès */
	}
}


/**
 * @brief  Initialise le driver XPT2046
 * @param  spi_handle Pointeur vers le handle SPI pour le tactile
 */
void XPT2046_Init(SPI_HandleTypeDef *spi_handle) {
	/* 1. Sécurité : Vérifier si le pointeur reçu est valide */
	if (spi_handle == NULL)
		return;
	/* 2. Assigner le bus spécifique (ex: hspi2) au pointeur interne */
	touch_spi_handle = spi_handle;

	uint8_t stop_cmd = 0x80;
	T_CS_Low();
	HAL_SPI_Transmit(touch_spi_handle, &stop_cmd, 1, 10);
	T_CS_High();
}

void Display_Calibration_Results(void) {
    char report[256]; // Un buffer assez large pour tout le texte

    // Effacer l'écran en noir
    FillRect(0, 0, ST7789_WIDTH, ST7789_HEIGHT, BLACK);

    // Préparation du texte avec des retours à la ligne (\n)
    // On affiche a, b, c (X) puis d, e, f (Y)
    snprintf(report, sizeof(report),
             "CALIBRATION OK\n\n"
             "Matrix X:\n"
             " a: %.4f\n"
             " b: %.4f\n"
             " c: %.2f\n\n"
             "Matrix Y:\n"
             " d: %.4f\n"
             " e: %.4f\n"
             " f: %.2f",
             myCalib.a, myCalib.b, myCalib.c,
             myCalib.d, myCalib.e, myCalib.f);

    // Affichage en une seule fois
    // Paramètres : x=20, y=40, texte, couleur=CYAN, fond=BLACK, taille=2, ta_font
    DrawString(20, 40, report, CYAN, BLACK, 1, &Font5x7);
}

#endif /* Display_ILI9488 */


void DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t thickness, uint32_t color) {
    int16_t dx = abs(x2 - x1);
    int16_t dy = -abs(y2 - y1);
    int16_t sx = x1 < x2 ? 1 : -1;
    int16_t sy = y1 < y2 ? 1 : -1;
    int16_t err = dx + dy;
    int16_t e2;

    while (1) {
        // Au lieu de 1x1, on dessine un carré centré sur le point
        // Cela simule l'épaisseur du pinceau Python
        if (thickness <= 1) {
            FillRect(x1, y1, 1, 1, color);
        } else {
            FillRect(x1 - (thickness/2), y1 - (thickness/2), thickness, thickness, color);
        }

        if (x1 == x2 && y1 == y2) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x1 += sx; }
        if (e2 <= dx) { err += dx; y1 += sy; }
    }
}

/**
 * @brief  Délai en millisecondes
 * @param  ms Nombre de millisecondes à attendre
 */
void Delay_MS(uint32_t ms) {
	uint32_t start = HAL_GetTick();
	while ((HAL_GetTick() - start) < ms) {
		__NOP(); /* Instruction processeur vide pour ne rien faire */
	}
}
