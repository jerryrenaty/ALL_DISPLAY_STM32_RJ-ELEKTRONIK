#ifndef FONT_H
#define FONT_H

#include <DISPLAYS_RJ-ELEKTRONIK.h>
#include <stdint.h>
extern SPI_HandleTypeDef *hspi;


/* Définition d'une police */
typedef struct {
    const uint16_t *data;   // pour polices > 8 bits de hauteur
    uint8_t width;
    uint8_t height;
    uint8_t firstChar;
    uint8_t lastChar;
} Font;

/* Polices externes */
extern const Font Font5x7;
extern const Font Font7x10;
extern const Font Font11x18;

//----------------------------------------Gestion des Font---------------------------------------------------------------------------------


#if Display_ILI9488
void DrawChar(uint16_t x, uint16_t y, char c, uint32_t color,uint32_t bg, uint8_t size, const Font *font);
void DrawString(uint16_t x, uint16_t y, const char *str,uint32_t color, uint32_t bg, uint8_t size, const Font *font);
#else
void DrawChar(uint16_t x, uint16_t y, char c, uint16_t color,
		uint16_t bg, uint8_t size, const Font *font);
void DrawString(uint16_t x, uint16_t y, const char *str,
		uint16_t color, uint16_t bg, uint8_t size, const Font *font);
#endif
void DrawChar_Landscape(uint16_t x_paysage, uint16_t y_paysage, char c, uint32_t color, uint32_t bg, uint8_t size, const Font *font) ;
void DrawString_Landscape(uint16_t x, uint16_t y, const char *str, uint32_t color, uint32_t bg, uint8_t size, const Font *font) ;
void FillRect_texte(uint16_t x, uint16_t y, uint16_t w, uint16_t h,
		uint16_t color) ;
#endif /* FONT_H */
