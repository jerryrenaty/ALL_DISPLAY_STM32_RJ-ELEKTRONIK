/**
 ******************************************************************************
 * @file    ST7789_RJ-ELEKTRONIK.h
 * @author  JERRYRENATY - RJ-ELEKTRONIK
 * @brief   Pilote d'affichage TFT LCD pour GC9A01 / ST7789 sur interface SPI
 * @version 1.0.0
 * @date    31 décembre 2025
 *
 * @note    Ce pilote fournit un support hybride SPI bloquant/DMA pour
 *          des performances optimales sur les microcontrôleurs STM32.
 ******************************************************************************
 */

#ifndef INC_DISPLAYS_RJ_ELEKTRONIK_H_
#define INC_DISPLAYS_RJ_ELEKTRONIK_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Fichier de configuration utilisateur */
#include <RJ-ELEKTRONIK_display_conf.h>
#include <math.h>

/*
 ******************************************************************************
 *                         MACROS DE CONTRÔLE BAS NIVEAU
 ******************************************************************************
 */

#define CS_Low()         HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET)
#define CS_High()        HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET)
#define DC_Command()     HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_RESET)
#define DC_Data()        HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET)

#if Display_ST7735
#else
#define RST_Low()        HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_RESET)
#define RST_High()       HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_SET)
#endif

/******************************************************************************/
#if Display_ILI9488
#define T_CS_Low()       HAL_GPIO_WritePin(T_CS_GPIO_Port, T_CS_Pin, GPIO_PIN_RESET)
#define T_CS_High()      HAL_GPIO_WritePin(T_CS_GPIO_Port, T_CS_Pin, GPIO_PIN_SET)
#endif

/*
 ******************************************************************************
 *                         CONFIGURATION DMA ET MÉMOIRE
 ******************************************************************************
 */

#if USE_DMA_INTEGRATION
/* Tampon dimensionné pour la largeur maximale afin d'optimiser le débit */
#if Display_ST7735
    #define DMA_BUFFER_SIZE  (2 * 160 * 2)
#elif Display_7789
    #define DMA_BUFFER_SIZE  (4 * 280 * 2)
#elif Display_GC9A01
    #define DMA_BUFFER_SIZE  (2 * 240 * 2)
#elif Display_ILI9488
    #define DMA_BUFFER_SIZE  (480 * 10 * 3)
#else
    #error "Aucun écran sélectionné pour DMA_BUFFER_SIZE"
#endif
#endif

/*
 ******************************************************************************
 *                         PALETTE DE COULEURS (RGB565)
 ******************************************************************************
 */

#if Display_ILI9488
#define BLACK         0x000000  /* R:0, G:0, B:0   */
#define WHITE         0xFFFFFF  /* R:63, G:63, B:63 */
#define RED           0xFF0000  /* R:63, G:0, B:0   */
#define GREEN         0x00FF00  /* R:0, G:63, B:0   */
#define BLUE          0x0000FF  /* R:0, G:0, B:63   */
#define YELLOW        0xFFFF00  /* R:63, G:63, B:0  */
#define CYAN          0x00FFFF  /* R:0, G:63, B:63  */
#define MAGENTA       0xFF00FF  /* R:63, G:0, B:63  */
#define ORANGE        0xFFA500  /* R:63, G:41, B:0  */
#define PURPLE        0x800080  /* R:32, G:0, B:32  */
#define PINK          0xFFC0CB  /* R:63, G:48, B:51 */
#define LIME          0x00FF00  /* R:0, G:63, B:0   */
#define TEAL          0x008080  /* R:0, G:32, B:32  */
#define NAVY          0x000080  /* R:0, G:0, B:32   */
#define MAROON        0x800000  /* R:32, G:0, B:0   */
#define OLIVE         0x808000  /* R:32, G:32, B:0  */
#define TRANSPARENT   0xFFFFFF  /* Géré par logiciel */
#else
#define BLACK         0x0000
#define WHITE         0xFFFF
#define RED           0xF800
#define GREEN         0x07E0
#define BLUE          0x001F
#define YELLOW        0xFFE0
#define CYAN          0x07FF
#define MAGENTA       0xF81F
#define ORANGE        0xFD20
#define PURPLE        0x8010
#define PINK          0xFC1F
#define LIME          0x87E0
#define TEAL          0x0410
#define NAVY          0x0010
#define MAROON        0x8000
#define OLIVE         0x8400
#define TRANSPARENT   0xFFFF
#endif

/*
 ******************************************************************************
 *                         DÉFINITIONS PERSONNALISÉES ET TYPES
 ******************************************************************************
 */

/**
 * @brief  Énumération des rotations d'affichage
 */
typedef enum {
    ROTATION_0,   /**< Portrait / Orientation par défaut      */
    ROTATION_90,  /**< Paysage                                 */
    ROTATION_180, /**< Portrait inversé                        */
    ROTATION_270  /**< Paysage inversé                         */
} Rotation;

#if Display_ILI9488
/**
 * @brief  Structure pour un point tactile
 */
typedef struct {
    uint16_t x;
    uint16_t y;
} TouchPoint;

uint8_t XPT2046_GetPointSafe(TouchPoint *p_out);


/**
 * @brief  Structure de calibration tactile
 */
typedef struct {
    float a;
    float b;
    float c;
    float d;
    float e;
    float f;
    uint8_t isCalibrated;
} TouchCalib;

#define XPT2046_ADDR_X      0x90   /* Adresse de lecture axe X */
#define XPT2046_ADDR_Y      0xD0   /* Adresse de lecture axe Y */
#endif

/*
 ******************************************************************************
 *                         VARIABLES GLOBALES PARTAGÉES
 ******************************************************************************
 */

extern SPI_HandleTypeDef *hspi;          /**< Pointeur vers le handle SPI */
extern Rotation currentRotation;         /**< Rotation actuelle de l'affichage */
extern uint16_t Display_Width;    /**< Largeur actuelle de l'affichage */
extern uint16_t Display_Height;   /**< Hauteur actuelle de l'affichage */

void Delay_MS(uint32_t ms);              /**< Fonction de délai milliseconde */

#if USE_DMA_INTEGRATION
extern uint8_t dma_buffer[DMA_BUFFER_SIZE]; /**< Tampon de transfert DMA */
#endif

/*
 ******************************************************************************
 *                         PROTOTYPES DES FONCTIONS SYSTÈME
 ******************************************************************************
 */

/** @brief  Initialisation matérielle */
void Display_Init(SPI_HandleTypeDef *hspi);

/** @brief  Communication bas niveau */
void WriteCommand(uint8_t cmd);
void WriteData(uint8_t data);
void WriteData16(uint16_t data);

/** @brief  Gestion de l'affichage */
void SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
void SetRotation(Rotation rotation);
void DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t thickness, uint32_t color);
/*
 ******************************************************************************
 *                         FONCTIONS DE DESSIN (MODES DÉDIÉS)
 ******************************************************************************
 */

#if USE_SPI_BLOQUANT
/* --- Fonctions Standard (Bloquantes) --- */
    #if Display_ILI9488
void FillScreen(uint32_t color);
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint32_t color);
    #else
void FillScreen(uint16_t color);
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
    #endif

void DrawBitmap(uint16_t x, uint16_t y, const uint16_t *bitmap, uint16_t w,
                uint16_t h);
#endif

#if USE_DMA_INTEGRATION
/* --- Fonctions Haute Performance (DMA) --- */
    #if Display_ILI9488
void Display_Calibration_Results(void);
void FillScreen(uint32_t color);
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint32_t color);
void DrawBitmapFullZoom(const uint16_t *bitmap);
    #else
void FillScreen(uint16_t color);
void FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
    #endif

bool DMA_IsBusy(void);                                  /**< Vérifie si le DMA est occupé */
void WaitDMA(void);                                      /**< Attend la fin du transfert DMA */
void DMA_Complete(void);                                 /**< Callback de fin de transfert DMA */
void SendBufferDMA(uint8_t *buffer, uint32_t buffer_size, uint16_t num_lines); /**< Envoie un tampon par DMA */
void DrawBitmap(uint16_t x, uint16_t y, const uint16_t *bitmap, uint16_t w,
                uint16_t h);
#endif

#if Display_ILI9488
/**
 * @brief  Fonctions de gestion du tactile XPT2046 pour ILI9488
 */

/** Initialise le driver avec le bus SPI sélectionné */
void XPT2046_Init(SPI_HandleTypeDef *hspi);

/** Vérifie si l'écran est actuellement touché (état physique du pin IRQ) */
uint8_t XPT2046_IsPressed(void);

/** Récupère les coordonnées X et Y converties en pixels écran */
TouchPoint XPT2046_GetPoint(void);

/** Lance la procédure de calibration interactive sur l'écran */
void XPT2046_Calibrate(void);

#endif

#ifdef __cplusplus
}
#endif

/*
 ******************************************************************************
 *                DÉVELOPPÉ PAR RJ-ELEKTRONIK © 2026
 ******************************************************************************
 */

#endif /* INC_DISPLAYS_RJ_ELEKTRONIK_H_ */
